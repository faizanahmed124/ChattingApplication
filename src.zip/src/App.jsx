import React, { useState } from 'react';
import ContactList from './components/ContactList';
import ChatWindow from './components/ChatWindow';
import Navbar from './components/Navbar';

const App = () => {
  const [selectedContact, setSelectedContact] = useState(null);

  return (
  
    <div className="flex h-screen">
      
      <ContactList onSelectContact={setSelectedContact} />
      {selectedContact && <ChatWindow contact={selectedContact} />}
    </div>
  );
};

export default App;
