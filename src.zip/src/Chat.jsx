// Chat.js
import React from 'react';

const Chat = ({ contact, addChat }) => {
  // Use useEffect to handle adding new chat when component mounts
  React.useEffect(() => {
    addChat(contact);
  }, [addChat, contact]);

  return (
    <div className="h-full flex flex-col justify-center items-center">
      <h2 className="text-lg font-bold mb-4">Chat with {contact.name}</h2>
      <div className="overflow-y-auto max-h-full w-full">
        {/* Render chat messages here */}
        {/* Example message */}
        <div className="flex justify-end mb-2">
          <div className="bg-gray-200 rounded-lg p-2">Hey! How are you?</div>
        </div>
        {/* End of example */}
      </div>
    </div>
  );
};

export default Chat;
